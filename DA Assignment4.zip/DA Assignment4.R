mydata4<-read.csv(file="~/desktop/train.csv", header=TRUE, sep=",")

ggplot(mydata4, aes(factor(Survived),Age)) + geom_boxplot(aes(fill = factor(Survived)))

ggplot(mydata4, aes(factor(Survived),Fare)) + geom_boxplot(aes(fill = factor(Survived)))

mydata4$family <- 1 + mydata4$SibSp + mydata4$Parch

ggplot(mydata4, aes(x = family)) + geom_histogram(colour="black",fill="blue",binwidth = 2) + theme_bw()

ggplot(mydata4, aes(x = Age)) + geom_histogram(colour="darkgreen",fill="white",binwidth = 2) + theme_bw()

ggplot(mydata4, aes(x = Survived, fill = Sex)) + geom_bar() + facet_grid(Sex ~ .) + theme_bw()

ggplot(mydata4, aes(x = Survived, fill = Embarked)) + geom_bar() + facet_grid(Embarked ~ .) + theme_bw()

ggplot(mydata4, aes(factor(Survived), Age)) + geom_violin(colour="blue",fill="purple") + theme_bw()

ggplot(mydata4, aes(factor(Survived), Fare)) + geom_violin() + theme_bw()

mydata4.m<-ddply(mydata4.m, .(variable), transform,rescale = rescale(value))

(p <- ggplot(nba.m, aes(variable, Name)) + geom_tile(aes(fill = rescale),colour = "white") + scale_fill_gradient(low = "white",high= "steelblue"))